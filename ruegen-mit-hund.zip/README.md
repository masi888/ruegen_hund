# Rügen mit Hund – Bester Direktpreis (MVP)

**So setzt du es online ohne Programmierkenntnisse:**
1. Erstelle ein neues leeres GitHub-Repository.
2. Lade alle Dateien aus diesem ZIP hoch (gleiche Ordnerstruktur).
3. Verbinde das Repo in https://vercel.com → New Project → Deploy.
4. Öffne die URL, die Vercel dir zeigt. Fertig.

**Optional (stündliche Aktualisierung):**
- In Vercel → Project Settings → Cron Jobs → URL `/api/refresh`, Schedule `Hourly`.

Später kannst du echte Hotel-Provider anbinden (Expedia Rapid, Hotelbeds, Google Hotel Ads).
